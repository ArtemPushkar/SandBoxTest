import { Component } from "@angular/core";

@Component({
  selector: "str2-root",
  templateUrl: "./str2.component.html"
})
export class Str2Component {}
