import { Component } from "@angular/core";

@Component({
  selector: "str1-root",
  templateUrl: "./str1.component.html"
})
export class Str1Component {}
